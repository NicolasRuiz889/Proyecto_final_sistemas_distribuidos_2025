package com.corhuila.AgendaManager;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AgendaManagerApplicationTests {

	@Test
	void contextLoads() {
	}

}
