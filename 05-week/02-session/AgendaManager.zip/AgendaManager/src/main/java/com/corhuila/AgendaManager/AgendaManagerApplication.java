package com.corhuila.AgendaManager;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AgendaManagerApplication {

	public static void main(String[] args) {
		SpringApplication.run(AgendaManagerApplication.class, args);
	}

}
